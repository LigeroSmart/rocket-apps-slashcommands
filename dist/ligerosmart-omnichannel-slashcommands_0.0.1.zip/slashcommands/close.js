"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.closecommand = void 0;
class closecommand {
    constructor(app) {
        this.app = app;
        this.command = 'close';
        this.i18nParamsExample = 'close-command-example';
        this.i18nDescription = 'close-command-description';
        this.providesPreview = false;
    }
    ;
    async executor(context, read, modify, http, persis) {
        const message = modify.getCreator().startMessage();
        const rup = modify.getUpdater().getLivechatUpdater();
        const room = context.getRoom();
        const args = context.getArguments();
        await rup.closeRoom(room, args[0] || '');
    }
}
exports.closecommand = closecommand;
