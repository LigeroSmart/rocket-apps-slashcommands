"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LigerosmartOmnichannelSlashcommandsApp = void 0;
const App_1 = require("@rocket.chat/apps-engine/definition/App");
const close_1 = require("./slashcommands/close");
class LigerosmartOmnichannelSlashcommandsApp extends App_1.App {
    constructor(info, logger, accessors) {
        super(info, logger, accessors);
    }
    async extendConfiguration(configuration) {
        configuration.slashCommands.provideSlashCommand(new close_1.closecommand(this));
    }
}
exports.LigerosmartOmnichannelSlashcommandsApp = LigerosmartOmnichannelSlashcommandsApp;
